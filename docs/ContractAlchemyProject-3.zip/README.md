# BeneficiaryManager

This project provides a smart contract for managing beneficiary identities and their associated wallet addresses. It allows for adding, updating, and deactivating beneficiaries, ensuring a secure and verifiable link between beneficiaries and their trusts.
