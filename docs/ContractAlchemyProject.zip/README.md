# SmartTrust Factory

A smart contract factory for creating and deploying SmartTrust contracts. Each SmartTrust contract is unique to a user, ensuring a standardized and secure creation process.
